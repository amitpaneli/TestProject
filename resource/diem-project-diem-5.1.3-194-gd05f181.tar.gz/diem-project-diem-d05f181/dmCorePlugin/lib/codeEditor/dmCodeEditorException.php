<?php

class dmCodeEditorException extends dmException
{
  
}