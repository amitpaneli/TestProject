<?php

require_once(sfConfig::get('dm_core_dir').'/lib/vendor/php-user-agent/lib/phpUserAgentStringParser.php');

class dmUserAgentParser extends phpUserAgentStringParser
{
  
}