<?php

require_once(dirname(__FILE__).'/dmBase.php');

/*
 * Provides shortcuts to Symfony & Diem static methods
 */
class dm extends dmBase
{
  
}