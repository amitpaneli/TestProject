[?php

/**
 * Project form base class.
 *
 * @package    ##PROJECT_NAME##
 * @subpackage form
 * @author     ##AUTHOR_NAME##
 * @version    SVN: $Id$
 * @generator  <?php echo 'Diem ', constant('DIEM_VERSION'), "\n"?>
 */
abstract class BaseFormDoctrine extends dmFormDoctrine
{
  public function setup()
  {
    parent::setup();
  }
}