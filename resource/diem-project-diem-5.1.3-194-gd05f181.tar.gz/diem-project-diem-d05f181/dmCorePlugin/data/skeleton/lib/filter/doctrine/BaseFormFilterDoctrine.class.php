<?php

/**
 * Project filter form base class.
 */
abstract class BaseFormFilterDoctrine extends dmFormFilterDoctrine
{
}
