<?php

/**
 * Base project form.
 */
class BaseForm extends dmForm
{
}
