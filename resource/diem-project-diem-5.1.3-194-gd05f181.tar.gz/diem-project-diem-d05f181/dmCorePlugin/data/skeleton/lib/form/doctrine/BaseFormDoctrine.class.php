<?php

/**
 * Project doctrine form base class.
 */
abstract class BaseFormDoctrine extends dmFormDoctrine
{
}