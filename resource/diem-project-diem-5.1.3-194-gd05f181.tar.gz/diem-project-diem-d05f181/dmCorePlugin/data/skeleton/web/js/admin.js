(function($)
{

  // Here is the entry point for your admin javascript
  
})(jQuery);