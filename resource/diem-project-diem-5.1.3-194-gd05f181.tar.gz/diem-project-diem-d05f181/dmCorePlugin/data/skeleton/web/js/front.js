(function($)
{
	
  // Here is the entry point for your front javascript
  
})(jQuery);