<?php

require_once(dm::getDir().'/dmAdminPlugin/lib/config/dmAdminApplicationConfiguration.php');

class adminConfiguration extends dmAdminApplicationConfiguration
{
  public function configure()
  {
    
  }
}