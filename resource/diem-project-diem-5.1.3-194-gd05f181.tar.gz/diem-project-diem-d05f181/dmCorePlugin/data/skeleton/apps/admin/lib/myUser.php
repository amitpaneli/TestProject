<?php

class myUser extends dmAdminUser
{
  
}