<?php

class myUser extends dmFrontUser
{

}