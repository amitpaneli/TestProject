(function($) {
  
$.widget('ui.dmAdminMediaBar', $.extend({}, $.dm.coreMediaBar, {

  _init : function() {
    this.initMediaBar();
  }
  
}));

})(jQuery);