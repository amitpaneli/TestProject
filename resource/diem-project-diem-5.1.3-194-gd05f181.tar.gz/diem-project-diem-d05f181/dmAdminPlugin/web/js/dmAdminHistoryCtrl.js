(function($) {
  
$("div.dm_history").tabs();

})(jQuery);