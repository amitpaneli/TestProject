(function($)
{

$('div.dm_config_panel').dmCoreTabForm({});

})(jQuery);
