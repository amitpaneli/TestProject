<?php

interface dmChartInterface
{
  
  public function getImage();
  
}