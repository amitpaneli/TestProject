<?php

class dmAdminRequest extends dmRequest
{

}