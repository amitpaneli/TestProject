<?php

class myAdminBaseComponents extends dmAdminBaseComponents
{
  
}