<?php

class dmAdminBaseComponents extends dmBaseComponents
{

}