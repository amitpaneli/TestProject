<?php

class dmAdminBaseActions extends dmBaseActions
{
  
}