<?php

class myAdminBaseGeneratedModuleActions extends dmAdminBaseGeneratedModuleActions
{
  
}