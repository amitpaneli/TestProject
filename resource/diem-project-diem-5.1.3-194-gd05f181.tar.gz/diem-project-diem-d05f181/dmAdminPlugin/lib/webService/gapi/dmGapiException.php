<?php

class dmGapiException extends dmException
{
  
}