<?php

/**
 * dmTransUnit module configuration.
 *
 * @package    lantenora
 * @subpackage dmTransUnit
 * @author     thibault d
 * @version    SVN: $Id: form.php 12474 2008-10-31 10:41:27Z fabien $
 */
class DmTransUnitAdminForm extends BaseDmTransUnitForm
{
}