<?php

/**
 * dmTransUnit module configuration.
 *
 * @package    lantenora
 * @subpackage dmTransUnit
 * @author     thibault d
 * @version    SVN: $Id: configuration.php 12474 2008-10-31 10:41:27Z fabien $
 */
class dmTransUnitGeneratorConfiguration extends BaseDmTransUnitGeneratorConfiguration
{
}
