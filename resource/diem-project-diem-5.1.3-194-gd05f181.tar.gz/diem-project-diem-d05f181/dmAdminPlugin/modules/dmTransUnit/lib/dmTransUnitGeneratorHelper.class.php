<?php

/**
 * dmTransUnit module helper.
 *
 * @package    lantenora
 * @subpackage dmTransUnit
 * @author     thibault d
 * @version    SVN: $Id: helper.php 12474 2008-10-31 10:41:27Z fabien $
 */
class dmTransUnitGeneratorHelper extends BaseDmTransUnitGeneratorHelper
{
}
