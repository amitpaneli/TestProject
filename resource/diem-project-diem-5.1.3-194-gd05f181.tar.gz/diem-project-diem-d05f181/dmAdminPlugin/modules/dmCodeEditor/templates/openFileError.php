<?php

echo _tag('div.file_tab.inner',
  _tag('div.inner_border',
    _tag('p.s16.s16_error.mt20.ml20', __($message))
  )
);