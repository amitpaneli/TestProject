<?php

require_once(dmOs::join(sfConfig::get('dm_admin_dir').'/modules/dmPage/lib/BasedmPageActions.class.php'));

class dmPageActions extends BasedmPageActions
{

}