<?php

require_once dirname(__FILE__).'/../lib/dmRedirectGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/dmRedirectGeneratorHelper.class.php';

/**
 * dmRedirect actions.
 *
 * @package    blancerf2
 * @subpackage dmRedirect
 * @author     thibault d
 * @version    SVN: $Id: actions.class.php 12474 2008-10-31 10:41:27Z fabien $
 */
class dmRedirectActions extends autoDmRedirectActions
{
}
