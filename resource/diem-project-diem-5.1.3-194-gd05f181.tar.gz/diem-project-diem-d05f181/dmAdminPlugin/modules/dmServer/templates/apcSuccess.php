<style type="text/css">
  iframe {
    width: 100%;
    height: 550px;
    background: none;
    border: none;
  }
</style>
<?php

echo _tag('iframe.mt10 src='._link('dmServer/includeApc')->getHref());