<?php

require_once dirname(__FILE__).'/../lib/dmSettingGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/dmSettingGeneratorHelper.class.php';

/**
 * dmSetting actions.
 *
 * @package    tourel
 * @subpackage dmSetting
 * @author     thibault d
 * @version    SVN: $Id: actions.class.php 12474 2008-10-31 10:41:27Z fabien $
 */
class dmSettingActions extends autoDmSettingActions
{
  
}