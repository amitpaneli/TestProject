<?php

/**
 * dmSetting module configuration.
 *
 * @package    tourel
 * @subpackage dmSetting
 * @author     thibault d
 * @version    SVN: $Id: form.php 12474 2008-10-31 10:41:27Z fabien $
 */
class DmSettingAdminForm extends BaseDmSettingForm
{
}