<?php

require_once dirname(__FILE__).'/../lib/dmCatalogueGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/dmCatalogueGeneratorHelper.class.php';

/**
 * dmCatalogue actions.
 *
 * @package    diem
 * @subpackage dmCatalogue
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 12474 2008-10-31 10:41:27Z fabien $
 */
class dmCatalogueActions extends autoDmCatalogueActions
{
}
