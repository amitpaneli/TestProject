<?php

/**
 * catalogue admin form
 *
 * @package    invenzzia
 * @subpackage catalogue
 * @author     Your name here
 */
class dmCatalogueAdminForm extends BasedmCatalogueForm
{
  public function configure()
  {
    parent::configure();
  }
}