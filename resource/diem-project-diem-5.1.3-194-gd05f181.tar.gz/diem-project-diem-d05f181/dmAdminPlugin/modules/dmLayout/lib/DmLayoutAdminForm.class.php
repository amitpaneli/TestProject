<?php

/**
 * dmLayout module configuration.
 *
 * @package    diem
 * @subpackage dmLayout
 * @author     Your name here
 * @version    SVN: $Id: form.php 12474 2008-10-31 10:41:27Z fabien $
 */
class DmLayoutAdminForm extends BaseDmLayoutForm
{

  public function configure()
  {
//    foreach(array('top', 'bottom', 'left', 'right') as $partType)
//    {
//      $this->widgetSchema[$partType]    = new sfWidgetFormInputCheckbox();
//      $this->validatorSchema[$partType] = new sfValidatorBoolean();
//    }
  }

}