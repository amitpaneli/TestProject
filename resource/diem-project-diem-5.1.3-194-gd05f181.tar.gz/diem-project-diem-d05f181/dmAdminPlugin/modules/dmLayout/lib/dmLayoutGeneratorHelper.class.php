<?php

/**
 * dmLayout module helper.
 *
 * @package    diem
 * @subpackage dmLayout
 * @author     Your name here
 * @version    SVN: $Id: helper.php 12474 2008-10-31 10:41:27Z fabien $
 */
class dmLayoutGeneratorHelper extends BaseDmLayoutGeneratorHelper
{
}
