<?php

echo _tag('div.dm_log.dm_data',
  $logView->render()
);