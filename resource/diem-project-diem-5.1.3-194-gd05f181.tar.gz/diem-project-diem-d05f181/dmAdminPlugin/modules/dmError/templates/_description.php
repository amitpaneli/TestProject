<?php

echo _tag('pre', $dmError->description);