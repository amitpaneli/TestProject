<?php

class BasedmAdminComponents extends dmAdminBaseComponents
{

}