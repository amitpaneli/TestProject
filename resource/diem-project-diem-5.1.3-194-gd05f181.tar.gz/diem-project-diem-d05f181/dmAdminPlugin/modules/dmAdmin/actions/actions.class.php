<?php

require_once(dmOs::join(sfConfig::get('dm_admin_dir').'/modules/dmAdmin/lib/BasedmAdminActions.class.php'));

class dmAdminActions extends BasedmAdminActions
{

}