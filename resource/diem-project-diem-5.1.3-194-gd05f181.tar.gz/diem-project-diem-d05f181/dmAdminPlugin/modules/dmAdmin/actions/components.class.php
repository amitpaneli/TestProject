<?php

require_once(dmOs::join(sfConfig::get('dm_admin_dir').'/modules/dmAdmin/lib/BasedmAdminComponents.class.php'));

class dmAdminComponents extends BasedmAdminComponents
{

}