<?php

echo _tag('div.dm_module_space_show.mt10', $menu->render());