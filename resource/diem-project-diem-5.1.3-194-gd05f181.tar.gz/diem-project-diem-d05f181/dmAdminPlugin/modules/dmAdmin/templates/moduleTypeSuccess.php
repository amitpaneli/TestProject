<?php

echo $menu->render();