<?php

echo _tag('h1', 'Wow, this page really does nothing at all');