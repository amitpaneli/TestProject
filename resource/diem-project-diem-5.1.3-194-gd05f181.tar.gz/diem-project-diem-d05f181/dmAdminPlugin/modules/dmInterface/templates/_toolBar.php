<?php

echo $sf_context->get('tool_bar_view')->render();