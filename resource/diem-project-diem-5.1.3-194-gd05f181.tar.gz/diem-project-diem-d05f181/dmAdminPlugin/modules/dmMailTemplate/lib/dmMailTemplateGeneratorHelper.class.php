<?php

/**
 * dmMailTemplate module helper.
 *
 * @package    diem-commerce
 * @subpackage dmMailTemplate
 * @author     Your name here
 * @version    SVN: $Id: helper.php 12474 2008-10-31 10:41:27Z fabien $
 */
class dmMailTemplateGeneratorHelper extends BaseDmMailTemplateGeneratorHelper
{
}
