<?php

/**
 * dmMailTemplate admin export
 *
 * @package    diem-commerce
 * @subpackage dmMailTemplate
 * @author     Your name here
 */
class DmMailTemplateAdminExport extends myDoctrineTableExport
{
}
