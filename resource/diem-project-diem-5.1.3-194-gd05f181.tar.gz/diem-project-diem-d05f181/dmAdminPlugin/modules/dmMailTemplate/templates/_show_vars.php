<?php

echo _tag('div.help_box', __('Variables you can use here:').' '.$dmMailTemplate->showVars());