<?php

/**
 * dmSentMail module configuration.
 *
 * @package    diem
 * @subpackage dmSentMail
 * @author     Your name here
 * @version    SVN: $Id: form.php 12474 2008-10-31 10:41:27Z fabien $
 */
class DmSentMailAdminForm extends BaseDmSentMailForm
{
  public function configure()
  {
    parent::configure();
  }
}