<?php

echo _tag('pre', $dmSentMail->debug_string);