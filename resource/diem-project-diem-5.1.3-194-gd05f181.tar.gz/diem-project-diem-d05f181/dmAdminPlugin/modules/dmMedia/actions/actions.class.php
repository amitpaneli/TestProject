<?php

require_once(dmOs::join(sfConfig::get('dm_admin_dir').'/modules/dmMedia/lib/BasedmMediaActions.class.php'));

class dmMediaActions extends BasedmMediaActions
{
  
}