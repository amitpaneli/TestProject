<?php

echo _open('div.dm_auto_seo_manager.mt10');

echo _tag('p.help_box', __('No module to manage.'));

echo _close('div');