<?php

echo _tag('div.s16.s16_info', __('This chart is not yet available.'));

echo _tag('p', 'It will activate soon, when your site have some data to analyze');