<?php

/**
 * ##MODULE_NAME## admin form
 *
 * @package    ##PROJECT_NAME##
 * @subpackage ##MODULE_NAME##
 * @author     ##AUTHOR_NAME##
 */
class ##MODEL_CLASS##AdminForm extends Base##MODEL_CLASS##Form
{
  public function configure()
  {
    parent::configure();
  }
}