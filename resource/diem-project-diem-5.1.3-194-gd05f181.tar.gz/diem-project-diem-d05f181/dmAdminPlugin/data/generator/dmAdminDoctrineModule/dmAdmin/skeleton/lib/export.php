<?php

/**
 * ##MODULE_NAME## admin export
 *
 * @package    ##PROJECT_NAME##
 * @subpackage ##MODULE_NAME##
 * @author     ##AUTHOR_NAME##
 */
class ##MODEL_CLASS##AdminExport extends myDoctrineTableExport
{
}
