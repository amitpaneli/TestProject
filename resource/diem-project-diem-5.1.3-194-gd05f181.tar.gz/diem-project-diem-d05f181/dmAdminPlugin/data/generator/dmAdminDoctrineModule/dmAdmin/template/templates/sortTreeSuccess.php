[?php

include_partial('dmAdminGenerator/sortTree', array('tree' => $tree, 'dm_module' => $dm_module));