[?php

include_partial('dmAdminGenerator/history', array('record' => $object, 'revisions' => $revisions));